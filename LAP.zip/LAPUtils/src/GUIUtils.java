import java.awt.Font;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.miginfocom.swing.MigLayout;

public class GUIUtils
{

	private static Font FONT_HEADER = new Font("Century Gothic", Font.BOLD, 16);
	private static Font FONT_ENTRY = new Font("Century Gothic", Font.PLAIN, 12);

	public static JPanel getViewFromResults(ResultSet result) throws SQLException
	{
		JPanel pnlResult = new JPanel();
		pnlResult.setLayout(new MigLayout());
		if (result == null)
		{
			return pnlResult;
		}

		ResultSetMetaData metaData = result.getMetaData();
		int columnCount = metaData.getColumnCount();

		for (int i = 1; i <= columnCount; i++)
		{
			JLabel lblHeader = new JLabel(metaData.getColumnLabel(i));
			lblHeader.setFont(FONT_HEADER);
			if (i == columnCount)
			{
				pnlResult.add(lblHeader, "gapright 2%, wrap");
			}
			else
			{
				pnlResult.add(lblHeader, "gapright 2%");
			}
		}

		while (result.next())
		{
			int colCounter = 1;
			while (colCounter <= columnCount)
			{
				JLabel lblHeader = new JLabel(result.getString(colCounter));
				lblHeader.setFont(FONT_ENTRY);
				if (colCounter == columnCount)
				{
					pnlResult.add(lblHeader, "gapright 2%,wrap");
				}
				else
				{
					pnlResult.add(lblHeader, "gapright 2%");
				}
				colCounter++;
			}
		}

		return pnlResult;
	}
}
