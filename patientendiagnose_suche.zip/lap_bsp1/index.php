<body style="padding: 2%">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

    <h3>Patientendiagnose - Suche</h3>
    <br>
    <form action="index.php" method="post">

        <div class="form-row form-group col-md-2">
            <label for="patientId">PatientenID</label>
            <input placeholder="z.B. 1" class="form-control mb-2" type="text" id="patientId" name="patientId" required>
        </div>
        <br>
        <br>
        <label>Zeitraum</label>
        <br>
        <br>
        <input class="form-check-input" type="radio" id="cm" name="timespan" value="cm" required>
        <label for="cm"> aktuelles Monat</label>
        <br>
        <input class="form-check-input" type="radio" id="lm" name="timespan" value="lm" required>
        <label for="lm"> vorheriger Monat</label>
        <br>
        <input class="form-check-input" type="radio" id="all" name="timespan" value="all"required>
        <label for="all"> alle Behandlungszeiträume</label>
        <br>
        <br>
        <button type="submit" onClick="javascript: return confirm('Suche durchführen?')" class="btn btn-primary">Suche</button>
    </form>
</body>
<?php


if ((isset($_POST['patientId']) && isset($_POST['timespan']))) {
    $patientId = $_POST['patientId'];
    $timeSpan = $_POST['timespan'];

    require_once('db_connection.php');
    require_once('utils.php');

    $db = getDbConn();

    $sql = 'select concat(p.firstname,\' \',p.lastname) as Patient,da.title as Diagnosebereich,d.title as Diagnose,pd.visit as Datum from patientsdiagnoses pd join patients p on p.id=pd.patients_id join diagnoses d on d.id=pd.diagnoses_id join diseaseareas da on d.diseaseareas_id=da.id where p.id='.$patientId;
    if ($timeSpan == 'lm') {
        $sql = $sql . ' and month(pd.visit)=month(now() - interval 1 month)';
    } else if ($timeSpan == 'cm') {
        $sql = $sql . ' and month(pd.visit)=month(now())';
    }
    $result = mysqli_query($db, $sql);

    genTableFromResult($result, false,'Für den Patienten mit der Id '.$patientId.' sind keine Diagnosen für den ausgewählten Zeitraum verfügbar');
}
