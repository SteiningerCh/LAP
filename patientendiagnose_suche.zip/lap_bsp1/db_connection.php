<?php

function getDbConn()
{
    $dbHost = "localhost";
    $dbUser = "root";
    $dbName = "praxis";

    $db = new mysqli($dbHost, $dbUser, "", $dbName);

    if ($db->connect_errno) {
        die('Verbindung zur Datenbank konnte nicht hergestellt werden');
    }

    return $db;
}
