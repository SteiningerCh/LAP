<?php

/**
 *   Creates a visual presentation of a sql result
 * 
 * 
 * @param Result $res The sql selection result
 * @param bool $hrefNeeded if the second entry should be a href link
 * 
 * @return void Echo's the results
 */
function genTableFromResult($res, $hrefNeeded,$noResultsFoundMsg)
{
    if ($res->num_rows === 0) {
        echo '<h3>'.$noResultsFoundMsg.'</h3>';
        return;
    }
    $fieldinfo = $res->fetch_fields();
    echo "<table class=\"table\">";
    echo "<tr>";
    foreach ($fieldinfo as $field) {
        echo "<th>" . $field->name . "</th>";
    }
    echo "</tr>";

    while ($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";
        $i = 1;
        foreach ($row as $val) {
            if ($hrefNeeded && $i == 2) {
                echo "<td><a href=\"detailAnsicht.php?kursnummer=" . $row['Kursnummer'] . "\">" . $val . "</a></td>";
            } else {
                echo "<td>" . $val . "</td>";
            }
            $i = $i + 1;
        }
        echo "</tr>";
    }
    echo "</table>";
}
