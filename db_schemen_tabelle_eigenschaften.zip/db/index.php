<body style="padding: 2%;background-color: #EAEAEA">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

    <h3>Datenbanken auflisten</h3>
    <br>
    <?php
    require_once('db_connection.php');
    require_once('utils.php');

    $db = getDbConn();

    if (!isset($_GET['schemaName']) && !isset($_GET['tableName'])) {
        $sql = 'show databases';
        $res = mysqli_query($db, $sql);


        echo '<form action="index.php" method="get"><ul class="list-group">';
        while ($row = mysqli_fetch_assoc($res)) {
            $schemaName = $row['Database'];

            echo '<li style="background-color: #EAEAEA" class="list-group-item d-flex justify-content-between align-items-center">';
            echo '<a>' . $schemaName . '</a>';
            echo '<button class="btn btn-primary" type="submit" name="schemaName" value="' . $schemaName . '">' . 'Auswählen' . '</button>';

            echo '</li>';
        }
        echo '</ul></form>';
    } else if (isset($_GET['schemaName']) && !isset($_GET['tableName'])) {
        echo '<h4>' . $_GET['schemaName'] . '</h4>';
        echo '<h3 style="margin-top: 4%">Tabellen: </h3>';


        $sql = 'SELECT table_name FROM information_schema.tables where table_schema=\'' . $_GET['schemaName'] . '\'';
        $res = mysqli_query($db, $sql);


        echo '<form action="index.php" method="get"><ul class="list-group">';
        echo '<input type="hidden" name="schemaName" value="' . $_GET['schemaName'] . '"/>';
        while ($row = mysqli_fetch_assoc($res)) {
            $tableName = $row['table_name'];

            echo '<li style="background-color: #EAEAEA" class="list-group-item d-flex justify-content-between align-items-center">';
            echo '<a>' . $tableName . '</a>';

            echo '<button class="btn btn-primary" type="submit" name="tableName" value="' . $tableName . '">' . 'Auswählen' . '</button>';

            echo '</li>';
        }
        echo '</ul></form>';
    } else if (isset($_GET['schemaName']) && isset($_GET['tableName'])) {

        echo '<h4>' . $_GET['schemaName'] . '</h4>';
        echo '<h3 style="margin-top: 4%">Tabelle: ' . $_GET['tableName'] . '</h3>';


        $sql = 'desc ' . $_GET['schemaName'] . '.' . $_GET['tableName'];
        $res = mysqli_query($db, $sql);

        genTableFromResult($res, false, false);
    }

    ?>
</body>
<?php

?>